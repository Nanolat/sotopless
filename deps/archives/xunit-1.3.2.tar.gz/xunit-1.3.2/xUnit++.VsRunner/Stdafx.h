#pragma once

#include <Windows.h>

#undef ReportEvent
